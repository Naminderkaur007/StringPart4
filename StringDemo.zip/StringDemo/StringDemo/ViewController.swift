


import UIKit

class ViewController: UIViewController{
    
    
    

    @IBOutlet weak var lblText: UILabel!
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        useOfReplaceSubRange()
    }
    
    func useOfReplaceSubRange(){
        
        //Replaces the specified subrange of elements with the given collection.
        
        //it will remove value from 1 to 3 index and add 1 value 5 times means its also increase the count
        
        var nums = [10, 20, 30, 40, 50]
        nums.replaceSubrange(1...3, with: repeatElement(1, count: 5))
        print("use with array = \(nums)")
        //[10, 1, 1, 1, 1, 1, 50]
        
        
        
        //Replaces the text within the specified bounds with the given characters.
        var strHelloWorld = "Hello world"
        
        let range = strHelloWorld.range(of: "world")
        
        strHelloWorld.replaceSubrange(range!, with: "Best")
        print("use with strings = \(strHelloWorld)")
        //Hello Best
        
    }
    
    func useOfAllSatisfy(){
        //if single character in string or string object in array not satisfy the conditon it will give false
        
        //Returns a Boolean value indicating whether every element of a sequence satisfies a given predicate.
        let namesStr = "helloWorld"
        let allHaveStr = namesStr.allSatisfy { (chrObj) -> Bool in
            return chrObj.isLowercase
        }
        print("Bool string = \(allHaveStr)")
        //true
        
        let namesArray = ["Sofia", "Camilla", "Martina", "Mateo", "Nicolás"]
        let allHaveAtLeastFiveArray = namesArray.allSatisfy { (strObj) -> Bool in
            return strObj.count >= 5
        }
        print("Bool array = \(allHaveAtLeastFiveArray)")
        //true
        
        
    }
    
    func useOfFirst(){
        
        
        //        Returns the first element of the sequence that satisfies the given predicate.
        let namesArray = ["Sofia", "Camilla", "Martina", "Mateo", "Nicolás", "Owl", "Oven"]
        let firstName = namesArray.first
        print("first Name without predicate = \(firstName)")
        //Optional("Sofia")
        
        
        let firstNamePredicate = namesArray.first { (strObj) -> Bool in
            return strObj.first == "O"
        }
        print("first Name start with O = \(firstNamePredicate)")
        //Optional("Owl")
        
    }
    
    func useOfLast(){
        //        Returns the last element of the sequence that satisfies the given predicate.
        let namesArray = ["Sofia", "Camilla", "Martina", "Mateo", "Nicolás", "Owl", "Oven"]
        
        let lastName = namesArray.last
        print("last Name without predicate = \(lastName)")
        //Optional("Oven")
        
        
        let lastNamePredicate = namesArray.last { (strObj) -> Bool in
            return strObj.last == "a"
        }
        print("last Name end with a = \(lastNamePredicate)")
        //Optional("Martina")
        
    }
    
    func useOfFirstIndexOf(){
        
        // loop will break when condition is satisfy
        
        //        Returns the first index where the specified value appears in the collection.
        var students = ["Ben", "Ivy", "Jordell", "Jassey","Maxime", "Maxime"]
        if let i = students.firstIndex(of: "Maxime"){
            students[i] = "Max"
        }
        print("Array of student after change = \(students)")
        //["Ben", "Ivy", "Jordell", "Jassey", "Max", "Maxime"]
        
        //        Returns the first index in which an element of the collection satisfies the given predicate.
        if let i = students.firstIndex(where: { (strObj) -> Bool in
            return strObj.hasPrefix("J")
        }){
            print("first object string start with J = \(students[i])")
            //Jordell
        }
        
    }
    
    func useOfLastIndexOf(){
        //        Returns the last index where the specified value appears in the collection.
        var students = ["Ben", "Ivy", "Jordell", "Jassey","Maxime", "Maxime"]
        if let i = students.lastIndex(of: "Maxime"){
            students[i] = "Max"
        }
        print("Array of student after change = \(students)")
        //  ["Ben", "Ivy", "Jordell", "Jassey", "Maxime", "Max"]
        
        //        Returns the index of the last element in the collection that matches the given predicate.
        if let i = students.lastIndex(where: { (strObj) -> Bool in
            return strObj.hasPrefix("J")
        }){
            print("first object string start with J = \(students[i])")
            //Jassey
        }
        
    }
    
    func useOfSubscript(){
        
        //subscript[]
        let streets = ["Adams", "Bryant", "Channing", "Douglas", "Evarts"]
        
        let streetsSlice = streets[2 ..< streets.endIndex]
        print("streets array = \(streetsSlice)")
        //["Channing", "Douglas", "Evarts"]
        
        
        let streetsSlicePartial = streets[2...]
        print("streets array with partial range = \(streetsSlicePartial)")
        //["Channing", "Douglas", "Evarts"]
        
        
        let str = "Greetings with partial Hello"
        
        let substr1 = str[str.startIndex...]
        
        print(substr1)
        
        
    }
    
    func useOfPrefix(){
        // A closure that takes an element of the sequence as its argument and returns true if the element should be included or false if it should be excluded. Once the predicate returns false it will not be called again.
        let streets = ["Adams", "Aryant", "channing", "Douglas", "Evarts", "Egg"]
        let ePrefix = streets.prefix { (firstObj) -> Bool in
            return firstObj.hasPrefix("A")
        }
        print("ePrefix = \(ePrefix)")
        
        let helloWorld = "HELLoWorld"
        let abc = helloWorld.prefix { (obj) -> Bool in
            return obj.isUppercase
        }
        
        print("dfdf = \(abc)")
        
        
        
    }
    
    func multiLine(){
        
       
        
        let quotation = """
        The White Rabbit put on his spectacles.  "Where shall I begin,
        please your Majesty?" he asked.

        "Begin at the beginning," the King said gravely, "and go on
        till you come to the end; then stop."
        """
        
        
        print(quotation)
        
        let softWrappedQuotation = """
        The White Rabbit put on his spectacles.  "Where shall I begin,
        please your Majesty?" he asked.

        "Begin at the beginning," the King said gravely, "and go on \
        till you come to the end; then stop."
        """
        
        print(softWrappedQuotation)
        
        let checkTextMultiline = """
ABCD
g
h
"""
        
        let checkTextSingleline = "GHfh"
        print(checkTextSingleline)
        print(checkTextMultiline)
        lblText.text = checkTextMultiline
        
    }
    
}


